#
# Sportr "python challenge"
#

from sys            import stdin
from urllib.request import urlopen
from html.parser    import HTMLParser

import json

def attrs2dict(attrs):

  dict = {}
  for attrValue in attrs:
    k,v = attrValue
    dict[k] = v
  return dict
    
class myParser(HTMLParser):
  def __init__(self,url):

    HTMLParser.__init__(self)
    self.count            = 0
    self.url              = url
    self.title            = None
    self.metaurl          = None
    self.metatitle        = None
    self.dict             = {}
    self.dict['headline'] = None
    self.dict['images']   = []
    self.images           = []
    
  def handle_starttag(self, tag, attrs):
    dict = attrs2dict(attrs)
    if tag == 'img':
      self.count += 1
    elif tag == 'meta' and 'property' in dict:
      property = dict['property']
      if property == "og:url":
        self.metaurl = dict['content']
      elif property == "og:title":
        if self.title is None:
          self.title = dict['content']
        self.metatitle = dict["content"]
      elif property == "og:image":
        elm = {'url':self.metaurl, 'caption':self.metatitle,'image':dict['content']} 
        self.images.append(elm)

lines = stdin.readlines()
lineNo = 0
output = []

for line in lines:

  lineNo += 1

  # Get rid of trailing '\n'...
  if line[-1] == '\n':
    line = line[:-1]

  # Get the page...    
  page = urlopen(line)
  contents = str(page.read()) # Had to convert to string for HTMLParser to work properly, yuck!!!
  dict = {}
  dict['url'] = line
  
  # Pull the page apart...  
  parser = myParser(line)
  parser.feed(contents)
  
  # If all there, put into dict and output...
  output.append({"url":parser.url,"headline":parser.title,"images":parser.images})

print(json.dumps(output))