#!/usr/bin/python
#coding=utf8
#===============================================================================
# Copyright (©) 2004-2017, Bruce Ferris (UK) Email: befe@bferris.co.uk
#===============================================================================
global verbose0
global verbose1
global verbose2

Y = YES = Yes = yes = yep  = True
N = NO  = No  = no  = nope = False

debug       = N
verboseAll  = N # To set them ALL on
verboseNone = N # To set them ALL off
verbose     = N # Verbose
verbose0    = Y
verbose1    = N
verbose2    = N
verbose3    = N
verbose4    = N
verbose5    = N
verboseTEMP = N

if verboseAll:
  verbose = verbose1 = verbose2 = verbose3 = verbose4 = verbose5 = True
if verboseNone:
  verbose = verbose1 = verbose2 = verbose3 = verbose4 = verbose5 = False

# Specialisations...
processOpTOSdebug = Y